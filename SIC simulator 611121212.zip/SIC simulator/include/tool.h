#ifndef __TOOL_H_
#define __TOOL_H_

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int exponent_Int(const int base, int n);

int hex_to_dex(char *hex);

int hex_to_dex_c(char hex);

#endif